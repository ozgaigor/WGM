from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
from PIL import ImageFilter
from PIL import ImageChops
from PIL import ImageOps
from PIL import ImageEnhance
from PIL import ImageStat as stat

im = Image.open('obraz.jpg')
print(im.size, im.mode)
#im.show()


w,h = im.size
s_w = 0.15
s_h = 0.27
resample_method =['NEAREST','LANCZOS','BILINEAR','BICUBIC','BOX','HAMMING']
im_N = im.resize((int(w*s_w), int(h*s_h)), 0) 
plt.figure(figsize=(20, 16))
i=1
for t in range(6):
    file_name = "resample_"+ str(resample_method[t])
    im_r = im.resize((int(w*s_w), int(h*s_h)), t)
    plt.subplot(6, 2, i)
    plt.title(str(file_name))
    plt.imshow(im_r)
    plt.axis('off')
    i +=1
    diff=ImageChops.difference(im_N,im_r)
    s = stat.Stat(diff)
    plt.subplot(6, 2, i)
    plt.title('srednia' + str(np.round(s.mean, 2)))
    plt.imshow(diff)
    plt.axis('off')
    i +=1
plt.savefig("fig1.png")

w_p = 45
h_p=25
w_k=460 
h_k=306
wycinek = (w_p, h_p, w_k, h_k) # definicja miejsca wycięcia w_p, h_p - lewy górny róg, w_k,h_k prawy dolny róg
wyc_w = wycinek[2] - wycinek[0] # szerokość wycinka
wyc_h = wycinek[3] - wycinek[1] # wysokość wycinka
s_w = 2 # skala dla szerokości
s_h = 2 # skala dla wysokości
glowa = im.resize((s_w * wyc_w, s_h * wyc_h) , box = wycinek)# wycina wycienek i zmienia rozmiar wycinka
#glowa.show()

glowa1 = im.crop(wycinek).resize(s_w * wyc_w, s_h * wyc_h)
#glowa1.show()

plt.figure(figsize=(32, 16))
plt.subplot(3,1,1) # ile obrazów w pionie, ile w poziomie, numer obrazu
plt.imshow(glowa, "gray")
plt.axis('off')
plt.subplot(3,1,2)
plt.imshow(glowa1, "gray")
plt.axis('off')
plt.subplot(3,1,3)
plt.imshow(ImageChops.difference(glowa,glowa1), "gray")
plt.axis('off')
plt.show()